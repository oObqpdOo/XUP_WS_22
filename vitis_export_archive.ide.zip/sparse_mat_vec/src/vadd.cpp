/**********
Copyright (c) 2021, Xilinx, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software
without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**********/


#include <algorithm>
#include <cstring>
#include <iostream>
#include <string>
#include <thread>
#include <unistd.h>
#include <vector>
#include <iomanip>

// This extension file is required for stream APIs
#include "CL/cl_ext_xilinx.h"
// This file is required for OpenCL C++ wrapper APIs
#include "xcl2.hpp"

#define SIZE 512

//Dummy data makes absolutely no sense yet
void vectors_init(float *vals, size_t *cols, size_t *rows, float *c, float *x, float *xnew, float *xsoft, size_t s) {
  // Fill the input vectors with random data
  for (size_t i = 0; i < s*s; i++) {
		  vals[i]    = std::rand() * ((std::rand() % 2) ? 1 : -1);
  }
  // Fill the input vectors with random data
  for (size_t i = 0; i < s*s; i++) {
		  vals[i] = i;
		  rows[i] = i;
  }
  for (size_t i = 0; i < s; i++) {
	c[i]    = std::rand() * ((std::rand() % 2) ? 1 : -1);
    x[i]    = std::rand() * ((std::rand() % 2) ? 1 : -1);
    xnew[i] = 0;
    for (size_t i=0;i<s;i++)
    {
    	for (size_t rptr=rows[i];rptr<rows[i+1];rptr++)
    	{
        	//ABS(x)
        	x[cols[rptr]]< 0 ? x[cols[rptr]]=-x[cols[rptr]] : x[cols[rptr]]=x[cols[rptr]];
    		xnew[i]+=vals[rptr]*x[cols[rptr]];
    	}
    }
  }
}

bool verify(float *sw_results, float *hw_results, size_t num_elements) {
  bool match = true;
  for (size_t i = 0; i < num_elements; i++) {
    if (sw_results[i] != hw_results[i]) {
      match = false;
      break;
    }
  }
  std::cout << "TEST " << (match ? "PASSED" : "FAILED") << std::endl;
  return match;
}

int main(int argc, char **argv) {
  
  // Check input arguments
  if (argc < 2 || argc > 4) {
    std::cout << "Usage: " << argv[0] << " <XCLBIN File> <#elements(optional)> <debug(optional)>" << std::endl;
    return EXIT_FAILURE;
  }
  // Read FPGA binary file
  auto binaryFile = argv[1];
  size_t num_elements = SIZE*SIZE;
  bool user_size = false;
  // Check if the user defined the # of elements
  if (argc >= 3){
    user_size = true;
    unsigned int val;
    try {
      val = std::stoi(argv[2]);
    }
    catch (const std::invalid_argument val) { 
      std::cerr << "Invalid argument in position 2 (" << argv[2] << ") program expects an integer as number of elements" << std::endl;
      return EXIT_FAILURE;
    }
    catch (const std::out_of_range val) { 
      std::cerr << "Number of elements out of range, try with a number lower than 2147483648" << std::endl;
      return EXIT_FAILURE;
    }
    num_elements = val;
    std::cout << "User number of elements enabled" << std::endl;
  }
  bool debug = false;
  // Check if the user defined debug
  if (argc == 4){
    std::string debug_arg = argv[3];
    if(debug_arg.compare("debug") == 0)
      debug = true;
    std::cout << "Debug enabled" << std::endl;
  }
  
  if (!user_size){
    // Define number of num_elements  
    if (xcl::is_hw_emulation())
      num_elements= SIZE*SIZE;
    else if (xcl::is_emulation())
      num_elements= SIZE*SIZE * 8;
    else{
      num_elements= SIZE*SIZE * SIZE;
    }
  }

  /*
  		val_type *vals,
  		dim_type *cols,
  		dim_type *rows,
  		val_type *c,
  		val_type *x,
  		val_type *xnew,
  		dim_type s)
  */


  // I/O Data Vectors
  size_t s = SIZE;
  std::vector<float, aligned_allocator<float>> vals(s*s);
  std::vector<size_t, aligned_allocator<size_t>> cols(s*s);
  std::vector<size_t, aligned_allocator<size_t>> rows(s*s);
  std::vector<float, aligned_allocator<float>> c(s);
  std::vector<float, aligned_allocator<float>> x(s);
  std::vector<float, aligned_allocator<float>> xnew(s);
  std::vector<float, aligned_allocator<float>> xsoft(s);

  // OpenCL Host Code Begins.
  // OpenCL objects
  cl::Device device;
  cl::Context context;
  cl::CommandQueue q;
  cl::Program program;
  cl::Kernel krnl_sparse_mat_vec;
  cl_int err;

  // get_xil_devices() is a utility API which will find the Xilinx
  // platforms and will return list of devices connected to Xilinx platform
  auto devices = xcl::get_xil_devices();

  // read_binary_file() is a utility API which will load the binaryFile
  // and will return the pointer to file buffer.
  auto fileBuf = xcl::read_binary_file(binaryFile);
  cl::Program::Binaries bins{{fileBuf.data(), fileBuf.size()}};
  bool valid_device = false;
  for (unsigned int i = 0; i < devices.size(); i++) {
    device = devices[i];
    // Creating Context and Command Queue for selected Device
    OCL_CHECK(err, context = cl::Context(device, NULL, NULL, NULL, &err));
    OCL_CHECK(err,
              q = cl::CommandQueue(context, device,
                                   CL_QUEUE_PROFILING_ENABLE |
                                       CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE,
                                   &err));
    std::cout << "Trying to program device[" << i
              << "]: " << device.getInfo<CL_DEVICE_NAME>() << std::endl;
    cl::Program program(context, {device}, bins, NULL, &err);
    if (err != CL_SUCCESS) {
      std::cout << "Failed to program device[" << i << "] with xclbin file!\n";
    } else {
      std::cout << "Device[" << i << "]: program successful!\n";
      // Creating Kernel
      OCL_CHECK(err, krnl_sparse_mat_vec  = cl::Kernel(program, "krnl_sparse_mat_vec" , &err));
      valid_device = true;
      break; // we break because we found a valid device
    }
  }
  if (!valid_device) {
    std::cout << "Failed to program any device found, exit!\n";
    exit(EXIT_FAILURE);
  }

  std::cout << "Running Vector add with " << num_elements << " elements" << std::endl;

  // Initialize the data vectors
  //vectors_init(buffer_a.data(), buffer_b.data(), sw_results.data(), hw_results.data(), num_elements);

  vectors_init(vals.data(), cols.data(), rows.data(), c.data(), x.data(), xnew.data(), xsoft.data(), s);

  // Running the kernel
  unsigned int size_bytes  = num_elements * sizeof(int);

  // Allocate Buffer in Global Memory
  // Buffers are allocated using CL_MEM_USE_HOST_PTR for efficient memory and
  // Device-to-host communication

  OCL_CHECK(err, cl::Buffer buffer_vals(context,
                                      CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                      size_bytes, vals.data(), &err));

  OCL_CHECK(err, cl::Buffer buffer_cols(context,
                                      CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                      size_bytes, cols.data(), &err));

  OCL_CHECK(err, cl::Buffer buffer_rows(context,
                                      CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                      size_bytes, rows.data(), &err));

  OCL_CHECK(err, cl::Buffer buffer_c(context,
                                      CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                      size_bytes, c.data(), &err));

  OCL_CHECK(err, cl::Buffer buffer_x(context,
                                      CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                      size_bytes, x.data(), &err));

  OCL_CHECK(err, cl::Buffer buffer_xnew(context,
                                      CL_MEM_USE_HOST_PTR | CL_MEM_WRITE_ONLY,
                                      size_bytes, xnew.data(), &err));


  // Setting Kernel Arguments krnl_sparse_mat_vec
  OCL_CHECK(err, err = krnl_sparse_mat_vec.setArg(0, buffer_vals));
  OCL_CHECK(err, err = krnl_sparse_mat_vec.setArg(1, buffer_rows));
  OCL_CHECK(err, err = krnl_sparse_mat_vec.setArg(2, buffer_cols));
  OCL_CHECK(err, err = krnl_sparse_mat_vec.setArg(3, buffer_c));
  OCL_CHECK(err, err = krnl_sparse_mat_vec.setArg(4, buffer_x));
  OCL_CHECK(err, err = krnl_sparse_mat_vec.setArg(5, buffer_xnew));

  //s-1 because code is crap and rows[i+1] gets accessed
  OCL_CHECK(err, err = krnl_sparse_mat_vec.setArg(6, (s*s)-1));

  // Copy input data to device global memory
  OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffer_vals, buffer_rows, buffer_cols, buffer_c, buffer_x}, 0 /* 0 means from host*/));
  OCL_CHECK(err, err = q.finish());

  // Launching the Kernels
  std::cout << "Launching Hardware Kernel..." << std::endl;
  OCL_CHECK(err, err = q.enqueueTask(krnl_sparse_mat_vec));
  // wait for the kernel to finish their operations
  OCL_CHECK(err, err = q.finish());

  // Copy Result from Device Global Memory to Host Local Memory
  std::cout << "Getting Hardware Results..." << std::endl;
  OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffer_xnew},CL_MIGRATE_MEM_OBJECT_HOST));
  OCL_CHECK(err, err = q.finish());

  // OpenCL Host Code Ends

  //Compare the device results with software results
  bool match = verify(xsoft.data(), xnew.data(), num_elements);

  if (debug){
  /*  for (unsigned int i = 0 ; i < num_elements; i++){
      std::cout << "Idx [" << std::setw(6) << i << "]" << std::setw(14) << buffer_a[i] << " + ";
      std::cout << std::setw(14) << buffer_b[i] <<"\tsw result" << std::setw(14);
      std::cout << sw_results[i] << "\thw result" << std::setw(14) << hw_results[i];
      std::cout << "\tequal "<< ((hw_results[i] == sw_results[i]) ? "True" : "False") << std::endl;
    }*/
	  for (unsigned int i = 0 ; i < num_elements; i++){
		  std::cout << "xnew[" << std::setw(6) << i << "]" << std::setw(14) << xnew[i] << std::endl;
	  }
  }

  return (match ? EXIT_SUCCESS : EXIT_FAILURE);
}
