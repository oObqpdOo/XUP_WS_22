
extern "C" {


// Matrix L: quadratic with dimension s x s, strict lower triangular matrix
// Vector x: length s
// Vector c: length s
// Vector xnew = c + L * abs(x)


void krnl_sparse_mat_vec(
		float *vals,
		unsigned long int *cols,
		unsigned long int *rows,
		float *c,
		float *x,
		float *xnew,
		unsigned long int s)
{
	#pragma HLS INTERFACE mode=m_axi bundle=gmem0 port=vals
	#pragma HLS INTERFACE mode=m_axi bundle=gmem1 port=cols
	#pragma HLS INTERFACE mode=m_axi bundle=gmem2 port=rows
	#pragma HLS INTERFACE mode=m_axi bundle=gmem3 port=c
	#pragma HLS INTERFACE mode=m_axi bundle=gmem4 port=x
	#pragma HLS INTERFACE mode=m_axi bundle=gmem5 port=xnew
    for (unsigned long int i=0;i<s;i++)
    {
		//#pragma HLS pipeline
    	#pragma HLS UNROLL factor=16
    	for (unsigned long int rptr=rows[i];rptr<rows[i+1];rptr++)
    	{
        	//ABS(x)
        	x[cols[rptr]]< 0 ? x[cols[rptr]]=-x[cols[rptr]] : x[cols[rptr]]=x[cols[rptr]];
    		xnew[i]+=vals[rptr]*x[cols[rptr]];
    	}
    }
}
}
